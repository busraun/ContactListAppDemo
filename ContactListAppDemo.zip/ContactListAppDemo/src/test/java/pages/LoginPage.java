package pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

import java.util.concurrent.TimeUnit;

public class LoginPage {

      WebDriver driver = Driver.getDriver();

    public void openURL() {
        System.out.println("Website is launching");
        driver.get("https://thinking-tester-contact-list.herokuapp.com/");
        System.out.println("Website is launching 2 ");

    }

    public void clickSignUpButton() {
        By signUpButton = By.id("signup");
        WebElement signupButton=driver.findElement(signUpButton);
        signupButton.click();
        System.out.println("signupButton is clicked ");
    }


}
