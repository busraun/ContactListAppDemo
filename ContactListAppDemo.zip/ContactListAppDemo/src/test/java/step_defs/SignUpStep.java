package step_defs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import pages.LoginPage;

import static utilities.Driver.driver;


public class SignUpStep {

    LoginPage loginPage = new LoginPage();



    @Given("user navigates base page")
    public void user_navigates_base_page() {
        loginPage.openURL();

    }

    @When("click sign up button")
    public void click_sign_up_button() {
        loginPage.clickSignUpButton();
    }


}
